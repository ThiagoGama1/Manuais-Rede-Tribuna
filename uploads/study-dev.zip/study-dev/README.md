# Monorepo - Projeto Web

## Estrutura

- `/frontend` -> Next.js + Tailwind
- `/backend` -> API (Go ou Java)
- `/docs` -> documentação do projeto

## Rodar o Frontend

```bash
cd frontend
npm install
npm run dev
```

## Funcionamento git

- `main` -> branch estável com a versão final do código. Nunca vamos desenvolver nada nela.

- `dev` -> branch de desenvolvimento que ocorrem mudanças frequentes.

- `feature/*` -> é a branch que vamos criar sempre que quisermos desenvolver uma funcionalidade nova de fato.

-> FLUXO DE TRABALHO:

/_ Entra na branch dev e atualiza para versão mais atual do time _/

- `git checkout dev`
- `git pull origin dev`

/_ Cria uma branch nova pra sua tarefa (EXEMPLO: login)_/

- `git checkout -b feature/login`

/_ Trabalha normalmente _/

- `git status` -> Vê o que foi alterado
- `git add .` -> Adiciona os arquivos para poder fazer o commit depois
- `git commit -m "feat: create login screen"` -> Faz o commit com uma mensagem

/_ Sobe a feature branch pro github _/

OBS: Esse primeiro comando é so pro primeiro pull, caso queira fazer commits depois basta dar `git push`.

- `git push -u origin feature/login`.

/_ Abre um Pull Request(PR) no github para poder dar merge com a branch dev _/

/_ Após o merge _/

- `git checkout dev`
- `git pull origin dev`

/_ Pode apagar a branch feature local e remoto _/

- `git branch -d feature/login`
- `git push origin --delete feature/login`

/_ Só mandamos pro main quando tivermos um conjunto de features prontas (Uma versão mais completa) _/

## Comandos Git

- `git branch` -> ver branch atual
- `git checkout dev` -> trocar de branch
- `git pull origin dev` -> atualizar sua branch com o github
- `git checkout -b feature/nome` -> Cria branch feature
