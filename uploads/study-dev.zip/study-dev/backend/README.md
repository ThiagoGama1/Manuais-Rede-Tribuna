# Backend

Este backend será implementado em:

- Golang (Gin/Fiber)
  ou
- Java (Spring Boot)

Porta sugerida:

- API: http://localhost:8080
